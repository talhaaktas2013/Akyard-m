
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Image } from "next/image";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <header className="text-center py-8">
        <img src="/logo.png" alt="Akyardım Oyun Logo" className="mx-auto w-24 h-24 rounded-full mb-4" />
        <h1 className="text-4xl font-bold">Akyardım Oyun</h1>
        <p className="text-gray-400">ETS 2 & Assetto Corsa Mod Rehberleri ve Linkleri</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
        <Card className="bg-gray-800">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold">🚛 ETS 2 Trafik Modu Kurulumu</h2>
            <p className="mt-2 text-gray-300">Trafik modunu nasıl kuracağını adım adım öğren. Uyumluluk, dosya yerleşimi ve sık yapılan hatalar.</p>
            <Button variant="secondary" className="mt-4">Detayları Gör</Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-800">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold">🏁 Assetto Corsa Mod Ekleme</h2>
            <p className="mt-2 text-gray-300">Arabalar, pistler ve online yarış için mod kurulum rehberleri. Sol + CSP ayarları da dahil.</p>
            <Button variant="secondary" className="mt-4">Rehbere Git</Button>
          </CardContent>
        </Card>
      </section>

      <section className="max-w-4xl mx-auto mt-8">
        <h2 className="text-2xl font-bold mb-4">📦 En Yeni Modlar & Paketler</h2>
        <ul className="list-disc list-inside text-gray-300">
          <li>
            <a href="https://drive.google.com/file/d/ets2trafikmodulink" className="text-blue-400 hover:underline" target="_blank">ETS 2 Gerçekçi Trafik Paketi v1.3 (Drive Link)</a>
          </li>
          <li>
            <a href="https://www.mediafire.com/file/assetto_turkiye_pist" className="text-blue-400 hover:underline" target="_blank">Assetto Corsa Türkiye Şehir Pisti v0.9 (Mediafire)</a>
          </li>
        </ul>
      </section>

      <footer className="text-center text-gray-500 mt-16 border-t border-gray-700 pt-4">
        © 2025 Akyardım Oyun. Tüm hakları saklıdır.
      </footer>
    </div>
  );
}
